jQuery(document).ready(function ($) {
    $(document).on('click', '#close-installing-popup', function () {
        $('#wrap-templates').removeClass('dt-whole-overlay');
        $('#template-installing-popup').fadeOut();
        $('#go-to-imported-page').fadeOut();
        $('#close-installing-popup').fadeOut();
        document.getElementById('final_response').innerText = '';
        document.getElementById('progress').innerText = '';
        document.getElementById('progress-bar').style.width = '0%';
        document.getElementById('progress-bar').innerText = '0%';
    });

    $(document).on('click', '.install-template', function () {

        $('#wrap-templates').addClass('dt-whole-overlay');

        let templateBtn = $(this);
        let templateKey = templateBtn.attr('data-key');
        let templateVerKey = templateBtn.attr('data-version-key');
        let templateThemeName = templateBtn.attr('data-theme-name');

        fetch('https://demo.peerduck.com/get-template.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                key: templateKey,
                verkey: templateVerKey,
                themename: templateThemeName,
            }),
        })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(html => {
                        console.error('Server error:\n' + html);
                        throw new Error('Server error (not JSON).');
                    });
                }
                return response.json();
            })
            .then(data => {
                if (!data.success) {
                    console.error('API error:', data.message);
                    alert(data.message);
                    $('#wrap-templates').removeClass('dt-whole-overlay');
                }
                if (data.success) {
                    $('#template-installing-popup').fadeIn();
                    doImport(data);
                }
            })
            .catch(error => {
                console.error('Fetch error:', error);
                alert('Connection error: ' + error);
            });
    });

    function doImport(data) {
        document.getElementById('progress').innerText = 'Starting import...';
        document.getElementById('progress').innerText = 'Import initialized.';
        document.getElementById('progress-bar').style.width = '10%';
        document.getElementById('progress-bar').innerText = '10%';

        let images = data.landing.images;

        if (images && images.length > 0) {
            startImport(data.landing);
        } else {
            document.getElementById('final_response').innerText = 'No images to import';
        }
    }

    function startImport(initial_data) {
        fetch(DuckThemesData.ajaxUrl, {
            method: 'POST',
            body: new URLSearchParams({
                action: 'duckthemes_import_template',
                data: JSON.stringify(initial_data),
            })
        })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(html => {
                        console.error('Server error:\n' + html);
                        throw new Error('Server error:\n' + html);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    processNextImage();
                } else {
                    alert('Error getting template: ' + data.message);
                }
            })
            .catch(error => {
                alert('Error: ' + error);
            });
    }

    function processNextImage() {
        const maxRetries = 3;
        let currentRetry = 0;
        let retryTimeout = 1000;

        function attemptProcessImage() {
            fetch(DuckThemesData.ajaxUrl, {
                method: 'POST',
                body: new URLSearchParams({
                    action: 'duckthemes_process_import_images',
                })
            })
                .then(response => {
                    if (!response.ok) {
                        return response.text().then(html => {
                            console.error('Server error:\n' + html);
                            throw new Error('Server error:\n' + html);
                        });
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        if (data.data.progress !== undefined) {

                            let progressBar = document.getElementById('progress-bar');
                            let progress = data.data.progress;
                            progressBar.style.width = progress + '%';
                            progressBar.innerText = progress + '%';

                            document.getElementById('progress').innerText = data.data.message;

                            currentRetry = 0;
                            retryTimeout = 1000;
                            processNextImage();
                        } else {
                            document.getElementById('final_response').innerText = data.data.message;
                            document.getElementById('progress').innerText = 'Import completed.';
                            document.getElementById('progress-bar').style.width = '100%';
                            document.getElementById('progress-bar').innerText = '100%';
                            let goToPage = $('#go-to-imported-page');
                            goToPage.attr('href', data.data.page_url);
                            goToPage.fadeIn();
                            $('#close-installing-popup').fadeIn();
                        }
                    } else {
                        console.error('Process image issue:', data);
                        // Skip image
                        if (data.data && data.data.retry) {
                            processNextImage();
                        }
                    }
                })
                .catch(error => {
                    console.error('Catch Error:', error);
                    if (currentRetry < maxRetries) {
                        currentRetry++;
                        retryTimeout *= 2;
                        setTimeout(attemptProcessImage, retryTimeout);
                    } else {
                        console.error('Error:', error);
                        document.getElementById('final_response').innerText = 'Error: ' + error.message;
                        currentRetry = 0;
                        retryTimeout = 1000;
                        processNextImage();
                    }
                });
        }

        attemptProcessImage();
    }


});
