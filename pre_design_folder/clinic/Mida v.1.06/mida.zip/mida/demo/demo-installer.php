<?php /** @noinspection DuplicatedCode */

/**
 * Class to install demo content
 * @version 1.00
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('DuckThemes_Demo_Installer')) {
    final class DuckThemes_Demo_Installer
    {
        private static ?DuckThemes_Demo_Installer $instance = null;

        public static function instance(): ?DuckThemes_Demo_Installer
        {
            if (is_null(self::$instance)) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        public function __construct()
        {
            add_action('admin_menu', array($this, 'add_appearance_submenu'));
            add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
            add_action('wp_ajax_duckthemes_import_template', array($this, 'import_template'));
            add_action('wp_ajax_duckthemes_process_import_images', array($this, 'process_import_images'));
            add_action('http_api_curl', array($this, 'set_custom_curl_options'), 10, 3);
        }

        function add_appearance_submenu()
        {
            add_submenu_page(
                'themes.php',
                'Import Templates',
                'Import Templates',
                'edit_theme_options',
                'duck-themes-import-templates',
                [$this, 'render_import_templates_page']
            );
        }

        function enqueue_scripts()
        {
            if (get_current_screen()->id === 'appearance_page_duck-themes-import-templates') {

                wp_enqueue_style(
                    'duck-themes-di-style',
                    get_template_directory_uri() . '/demo/demo-installer.css',
                    '',
                    wp_get_theme()->get('Version')
                );

                wp_enqueue_script(
                    'duck-themes-di-script',
                    get_template_directory_uri() . '/demo/demo-installer.js',
                    array('jquery'),
                    wp_get_theme()->get('Version'),
                    true
                );

                wp_localize_script('duck-themes-di-script', 'DuckThemesData', array(
                    'adminUrl' => admin_url('admin-post.php'),
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                ));

            }
        }

        function set_custom_curl_options($handle)
        {
            curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 30);
            curl_setopt($handle, CURLOPT_DNS_CACHE_TIMEOUT, 30);
            curl_setopt($handle, CURLOPT_TIMEOUT, 30);
        }

        function render_import_templates_page()
        {
            $templates = DuckThemes_Templates_Map::get_templates_map_array()['templates'];

            ob_start();

            echo '<div class="wrap">';

            echo '<h1 class="wp-heading-inline">';
            echo esc_html__('Import Templates', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</h1><br></br>';

            // Help Section
            echo '<div class="duck-themes-import-info" style="margin-bottom: 30px; padding: 20px; background-color: #f9f9f9; border: 1px solid #ddd; border-left-width: 4px; border-left-color: #0073aa;">';
            echo '<h2 style="margin-top: 0; color: #0073aa;">';
            echo esc_html__('Post-Import Setup Guide', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</h2>';
            echo '<p>';
            echo esc_html__('After importing the demo content, here\'s where you can customize your site:', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</p>';

            echo '<div class="help-item" style="margin-bottom: 15px;">';
            echo '<h3 style="margin-bottom: 5px; font-size: 1.1em;">';
            echo esc_html__('Theme Settings:', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</h3>';
            echo '<p style="margin-top: 0;">';
            echo sprintf(esc_html__('Most theme options are available in the %1$sAppearance -> Customize%2$s. ', DuckThemes_Templates_Map::DuckThemes_Theme_Domain), '<a href="' . esc_url(admin_url('customize.php')) . '" target="_blank">', '</a>', '<a href="https://' . 'docs.duckthemes.com/v3/theme-customization/" target="_blank">', '</a>'); // phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped, Generic.PHP.ForbiddenFunctions.Found -- Link to official documentation, considered safe here.
            echo '</p>';
            echo '</div>';

            echo '<div class="help-item" style="margin-bottom: 15px;">';
            echo '<h3 style="margin-bottom: 5px; font-size: 1.1em;">';
            echo esc_html__('Header & Menu:', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</h3>';
            echo '<p style="margin-top: 0;">';
            echo sprintf(esc_html__('Navigate to %1$sAppearance -> Menus%2$s to set up your navigation menu. Assign the primary menu in the menu locations settings.', DuckThemes_Templates_Map::DuckThemes_Theme_Domain), '<a href="' . esc_url(admin_url('nav-menus.php')) . '" target="_blank">', '</a>');
            echo '</p>';
            echo '</div>';

            echo '<div class="help-item" style="margin-bottom: 15px;">';
            echo '<h3 style="margin-bottom: 5px; font-size: 1.1em;">';
            echo esc_html__('Footer:', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</h3>';
            echo '<p style="margin-top: 0;">';
            echo sprintf(esc_html__('Footer widgets can be configured under %1$sAppearance -> Widgets%2$s. Copyright text are managed in the Customizer under "Footer Settings".', DuckThemes_Templates_Map::DuckThemes_Theme_Domain), '<a href="' . esc_url(admin_url('widgets.php')) . '" target="_blank">', '</a>');
            echo '</p>';
            echo '</div>';

            echo '<div class="help-item" style="margin-bottom: 15px;">';
            echo '<h3 style="margin-bottom: 5px; font-size: 1.1em;">';
            echo esc_html__('Applying Page Templates and Blog with Sidebar:', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</h3>';
            echo '<p style="margin-top: 0;">';
            echo esc_html__('To change a page\'s layout (e.g., full width, blog with sidebar), edit the page. In the Classic Editor, find the "Page Attributes" box and select a template from the dropdown. In the Block editor (Gutenberg), find the "Template" panel in the Page settings sidebar.', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</p>';
            echo '</div>';

            echo '<div class="help-item" style="margin-bottom: 15px;">';
            echo '<h3 style="margin-bottom: 5px; font-size: 1.1em;">';
            echo esc_html__('Black & White Menu Styles:', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</h3>';
            echo '<p style="margin-top: 0;">';
            echo esc_html__('For pages needing distinct black or white top menu bars, use these page templates: "Fullwidth + First Top Menu + Default Footer" or "Fullwidth + Second Top Menu + Default Footer".', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</p>';
            echo '</div>';

            echo '<div class="help-item" style="margin-bottom: 15px;">';
            echo '<h3 style="margin-bottom: 5px; font-size: 1.1em;">';
            echo esc_html__('How to fix Elementor stuck on the loading screen:', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</h3>';
            echo '<p style="margin-top: 0;">';
            echo sprintf(esc_html__('We can\'t provide support for third-party plugins directly, but you can follow the official Elementor help guide for this common issue: %1$sElementor Stuck on Loading Screen%2$s.', DuckThemes_Templates_Map::DuckThemes_Theme_Domain), '<a href="https://' . 'elementor.com/help/elementor-not-loading/" target="_blank">', '</a>');  // phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped, Generic.PHP.ForbiddenFunctions.Found -- Link to official documentation, considered safe here.
            echo '</p>';
            echo '</div>';

            echo '<div class="help-item" style="margin-bottom: 15px;">';
            echo '<h3 style="margin-bottom: 5px; font-size: 1.1em;">';
            echo esc_html__('Theme Translation:', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</h3>';
            echo '<p style="margin-top: 0;">';
            echo sprintf(esc_html__('To translate the theme into another language, we recommend using the %1$sLoco Translate%2$s plugin. It allows you to easily find and translate theme strings directly within the WordPress admin area. Other translation plugins like WPML or Polylang are also compatible.', DuckThemes_Templates_Map::DuckThemes_Theme_Domain), '<a href="https://wordpress.org/plugins/loco-translate/" target="_blank">', '</a>');
            echo '</p>';
            echo '</div>';

            echo '<div class="help-item" style="margin-bottom: 15px;">';
            echo '<h3 style="margin-bottom: 5px; font-size: 1.1em;">';
            echo esc_html__('Custom WooCommerce Shop Template:', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</h3>';
            echo '<p style="margin-top: 0;">';
            echo sprintf(esc_html__('If you need advanced customization for your WooCommerce shop, archive, product pages, and more, we recommend the %1$sShopLentor%2$s plugin (formerly WooLentor). It offers extensive WooCommerce building capabilities for Elementor.', DuckThemes_Templates_Map::DuckThemes_Theme_Domain), '<a href="https://wordpress.org/plugins/woolentor-addons/" target="_blank">', '</a>');
            echo sprintf(esc_html__('While we recommend ShopLentor, other plugins offer similar functionality. You can %1$ssearch for alternatives%2$s in the WordPress plugin directory.', DuckThemes_Templates_Map::DuckThemes_Theme_Domain), '<a href="https://wordpress.org/plugins/search/woocommerce+elementor+builder/" target="_blank">', '</a>');
            echo '</p>';
            echo '</div>';

            echo '<p>';
            echo esc_html__('Explore the Customizer for all available options to fine-tune your website\'s appearance!', DuckThemes_Templates_Map::DuckThemes_Theme_Domain);
            echo '</p>';
            echo '</div>';

            if (empty($templates)) {
                echo '<p class="templates-not-found">' . esc_html__('No templates found.', DuckThemes_Templates_Map::DuckThemes_Theme_Domain) . '</p>';
            } else {
                ?>
                <div id="wrap-templates" class="theme-browser rendered">
                    <?php

                    foreach ($templates as $key => $template) {
                        ?>
                        <div class="theme">
                            <div class="theme-screenshot">
                                <img src="<?php echo esc_url("https://demo.peerduck.com/demos/" . DuckThemes_Templates_Map::DuckThemes_Theme_Domain . "/" . $template['screenshot-folder'] . "/$key.png?v=1"); ?>"
                                     alt="<?php echo esc_attr($template['title']); ?>">
                            </div>
                            <a class="more-details" target="_blank"
                               href="<?php echo esc_url("https://" . DuckThemes_Templates_Map::DuckThemes_Theme_Domain . ".peerduck.com/$key"); ?>">
                                <?php echo esc_html__('Live Preview', DuckThemes_Templates_Map::DuckThemes_Theme_Domain); ?>
                            </a>
                            <div class="theme-id-container">
                                <h2 class="theme-name"><?php echo esc_html($template['title']); ?></h2>
                                <div class="theme-actions">
                                    <a class="button button-primary install-template"
                                       href="#"
                                       onclick="return false;"
                                       data-key="<?php echo esc_attr($key); ?>"
                                       data-version-key="<?php echo esc_attr($template['version-key']); ?>"
                                       data-theme-name="<?php echo esc_attr(DuckThemes_Templates_Map::DuckThemes_Theme_Domain); ?>"
                                    >
                                        <?php echo esc_html__('Import Template', DuckThemes_Templates_Map::DuckThemes_Theme_Domain); ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php
                    }

                    ?>
                </div>

                <div id="template-installing-popup" style="display:none;">
                    <div class="popup-content">
                        <div id="progress-container">
                            <div id="progress-bar">
                                0%
                            </div>
                        </div>
                        <div id="progress"></div>
                        <div id="final_response"></div>
                        <button id="close-installing-popup"
                                style="display:none;"><?php esc_html_e('Close', DuckThemes_Templates_Map::DuckThemes_Theme_Domain); ?></button>
                        <a href="#" id="go-to-imported-page"
                           style="display:none;"><?php esc_html_e('Go to imported page', DuckThemes_Templates_Map::DuckThemes_Theme_Domain); ?></a>
                    </div>
                </div>
                <?php
            }
            echo '</div>';

            echo ob_get_clean();

        }


        public function import_template(): void
        {
            if (!current_user_can('manage_options')) {
                return;
            }

            $import_data = json_decode(stripslashes($_POST['data']), true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                wp_send_json_error('JSON decode error: ' . json_last_error_msg());
                return;
            }

            if (isset($import_data['content']) && isset($import_data['images']) && isset($import_data['title'])) {
                $content = $import_data['content'];
                $image_data = $import_data['images'];

                $page_title = sanitize_text_field($import_data['title']);
                $elementor_version = sanitize_text_field($import_data['elementor_version']);

                delete_transient('elementor_import_content');
                delete_transient('elementor_import_images');
                delete_transient('elementor_import_total_images');
                delete_transient('elementor_import_images_processed');
                delete_transient('elementor_import_image_retry_count');
                delete_transient('elementor_import_page_title');
                delete_transient('elementor_import_elementor_version');

                set_transient('elementor_import_content', $content, 60 * 60);
                set_transient('elementor_import_images', $image_data, 60 * 60);
                set_transient('elementor_import_total_images', count($image_data), 60 * 60);
                set_transient('elementor_import_images_processed', 0, 60 * 60);
                set_transient('elementor_import_image_retry_count', [], 60 * 60);
                set_transient('elementor_import_page_title', $page_title, 60 * 60);
                set_transient('elementor_import_elementor_version', $elementor_version, 60 * 60);

                wp_send_json_success([
                    'message' => 'Import initialized...',
                    'images' => $image_data
                ]);
            } else {
                wp_send_json_error('Invalid import data.');
            }
        }

        private function replace_image_data(array &$array, $old_url, $new_url, $old_id, $new_id) {
            foreach ($array as &$value) {
                // If this is an array, check if it has both 'url' and 'id'
                if (is_array($value)) {
                    if (
                        isset($value['url'], $value['id']) &&
                        $value['url'] === $old_url &&
                        $value['id'] === $old_id
                    ) {
                        // Both url and id match => replace them
                        $value['url'] = $new_url;
                        $value['id'] = $new_id;
                    }

                    // Recursively check deeper nested arrays
                    $this->replace_image_data($value, $old_url, $new_url, $old_id, $new_id);
                }
            }
        }

        public function process_import_images(): void
        {
            if (!current_user_can('manage_options')) {
                wp_send_json_error('The current user can not manage options and create pages. Please change it in the WordPress settings.');
                return;
            }

            $start_time = time();
            $timeout = 30;

            $content = get_transient('elementor_import_content');
            $image_data = get_transient('elementor_import_images');
            $total_images = get_transient('elementor_import_total_images');
            $images_processed = get_transient('elementor_import_images_processed');
            $image_retry_count = get_transient('elementor_import_image_retry_count');
            $page_title = get_transient('elementor_import_page_title');
            $elementor_version = get_transient('elementor_import_elementor_version');

            if (!is_array($image_retry_count)) {
                $image_retry_count = [];
            }

            if ($images_processed < $total_images) {
                $current_image = $image_data[$images_processed];
                $url = $current_image['url'];
                if (!isset($image_retry_count[$url])) {
                    $image_retry_count[$url] = 0;
                }

                $new_image_id = $this->download_image_to_media_gallery($url, $image_retry_count[$url]);
                if ($new_image_id === false) {
                    $image_retry_count[$url]++;
                    set_transient('elementor_import_image_retry_count', $image_retry_count, 60 * 60);

                    if ($image_retry_count[$url] > 3) {
                        $images_processed++;
                        set_transient('elementor_import_images_processed', $images_processed, 60 * 60);
                        $progress = round(($images_processed / $total_images) * 90) + 10;

                        wp_send_json_success([
                            'progress' => $progress,
                            'message' => "Processed $images_processed of $total_images images.",
                            'image_url' => $url,
                            'images_processed' => $images_processed,
                            'new_image_id' => 'SKIPPED'
                        ]);
                    } else {
                        wp_send_json_error([
                            'retry' => true,
                            'image_url' => $url
                        ]);
                    }
                } else {
                    $new_url = wp_get_attachment_url($new_image_id);
                    $images_processed++;
                    set_transient('elementor_import_images_processed', $images_processed, 60 * 60);
                    $progress = round(($images_processed / $total_images) * 90) + 10;

                    $this->replace_image_data($content, $url, $new_url, $current_image['id'], $new_image_id);

                    set_transient('elementor_import_content', $content, 60 * 60);

                    wp_send_json_success([
                        'progress' => $progress,
                        'message' => "Processed $images_processed of $total_images images.",
                        'image_url' => $url,
                        'new_image_url' => $new_url
                    ]);
                }
            } else {
                $new_post_id = wp_insert_post([
                    'post_title' => $page_title,
                    'post_content' => '',
                    'post_status' => 'publish',
                    'post_type' => 'page',
                ]);

                if ($new_post_id) {
                    update_post_meta($new_post_id, '_elementor_data', wp_slash(json_encode($content)));
                    update_post_meta($new_post_id, '_elementor_edit_mode', 'builder');
                    update_post_meta($new_post_id, '_elementor_template_type', 'page');
                    update_post_meta($new_post_id, '_elementor_version', $elementor_version);

                    update_post_meta($new_post_id, '_wp_page_template', 'page-templates/template-full-width-page-without-header-title.php');

                    update_post_meta($new_post_id, '_wp_gutenberg_disable', '1');
                    update_post_meta($new_post_id, '_wp_gutenberg_enabled', '0');

                    delete_transient('elementor_import_content');
                    delete_transient('elementor_import_images');
                    delete_transient('elementor_import_total_images');
                    delete_transient('elementor_import_images_processed');
                    delete_transient('elementor_import_image_retry_count');
                    delete_transient('elementor_import_page_title');
                    delete_transient('elementor_import_elementor_version');

                    wp_send_json_success([
                        'message' => "Page imported successfully!",
                        'page_url' => get_permalink($new_post_id),
                    ]);
                } else {
                    wp_send_json_error('Failed to import page.');
                }
            }

            if (time() >= $start_time + $timeout) {
                wp_send_json_error('Process timeout, please resume the import.');
            }
        }

        public function download_image_to_media_gallery($image_url, $image_retry_count)
        {
            try {
                $start = microtime(true);
                $response = wp_remote_get($image_url, [ 'timeout' => 30 ]);
                $time_taken = microtime(true) - $start;
                error_log("[DUCK_THEMES_DEBUG] Download time for $image_url: $time_taken seconds");

                if (is_wp_error($response)) {
                    throw new Exception('HTTP request error: ' . $response->get_error_message());
                }

                $status_code = wp_remote_retrieve_response_code($response);
                if ($status_code !== 200) {
                    throw new Exception(
                        'HTTP status code ' . $status_code . ' when trying to download: ' . $image_url
                    );
                }

                $image_data = wp_remote_retrieve_body($response);
                if (empty($image_data)) {
                    throw new Exception('Failed to retrieve image data from URL: ' . $image_url);
                }

                $image_name = pathinfo(basename($image_url), PATHINFO_FILENAME);
                $image_extension = pathinfo(basename($image_url), PATHINFO_EXTENSION);
                $unique_image_name = $image_name . '-' . time() . '.' . $image_extension;

                $upload = wp_upload_bits( $unique_image_name, null, $image_data );
                if ( $upload['error'] ) {
                    throw new Exception( 'Error uploading file: ' . $upload['error'] );
                }
                $image_file = $upload['file'];

                $wp_filetype = wp_check_filetype($unique_image_name);
                $attachment = [
                    'post_mime_type' => $wp_filetype['type'],
                    'post_title' => sanitize_file_name($unique_image_name),
                    'post_content' => '',
                    'post_status' => 'inherit',
                ];

                $attach_id = wp_insert_attachment($attachment, $image_file);

                if ($image_retry_count > 1) {
                    add_filter('intermediate_image_sizes', '__return_empty_array', 999);
                }

                require_once ABSPATH . 'wp-admin/includes/image.php';
                $attach_data = wp_generate_attachment_metadata($attach_id, $image_file);
                wp_update_attachment_metadata($attach_id, $attach_data);

                if ($image_retry_count > 1) {
                    remove_filter('intermediate_image_sizes', '__return_empty_array', 999);
                }

                return $attach_id;
            } catch (Exception $e) {
                error_log('[DUCK_THEMES_ERROR] ' . $e->getMessage());
                return false;
            }
        }

    }

    DuckThemes_Demo_Installer::instance();
}