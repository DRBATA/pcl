<?php
/**
 * Customizer settings for this theme.
 * @since Mida 1.0
 */
if (!class_exists('Mida_Customize')) {
    /**
     * CUSTOMIZER SETTINGS
     */
    class Mida_Customize
    {

        /**
         * Register customizer options.
         *
         * @param WP_Customize_Manager $wp_customize Theme Customizer object.
         */
        public static function register($wp_customize)
        {
            /* ============================================================================================================================= */
            /* ============================================================================================================================= */
            /* ============================================================================================================================= */
            /*
             * COLORS
             */

            // Accent color
            $wp_customize->add_setting('accent-color', array(
                'default' => '#038A9D',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'accent-color', array(
                'section' => 'colors',
                'label' => esc_html__('Accent color', 'mida'),
                'description' => esc_html__('Sets main accent color.', 'mida'),
            )));


            // Accent color hover
            $wp_customize->add_setting('accent-color-hover', array(
                'default' => '#004552',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'accent-color-hover', array(
                'section' => 'colors',
                'label' => esc_html__('Accent color hover', 'mida'),
                'description' => esc_html__('Sets the color on hover for links.', 'mida'),
            )));


            // Text color for inner pages
            $wp_customize->add_setting('global-txt-color', array(
                'default' => '#004552',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'global-txt-color', array(
                'section' => 'colors',
                'label' => esc_html__('Text color', 'mida'),
                'description' => esc_html__('Sets the text color for inner pages.', 'mida')
            )));


            // Header title color
            $wp_customize->add_setting('header-title-txt-color', array(
                'default' => '#004552',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header-title-txt-color', array(
                'section' => 'colors',
                'label' => esc_html__('Header title color', 'mida')
            )));


            // Header background overlay color
            $wp_customize->add_setting('header-bg-overlay-color', array(
                'default' => '#c1dce0',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header-bg-overlay-color', array(
                'section' => 'colors',
                'label' => esc_html__('Header background overlay color', 'mida'),
                'description' => esc_html__("Changes the header background overlay color. If there is no changing of the color that means the current page uses Elementor builder’s header instead of the site's global, so you need to change the color on the page.", 'mida'),
            )));


            // Header menu color - first
            $wp_customize->add_setting('header-menu-txt-color-first', array(
                'default' => '#004552',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header-menu-txt-color-first', array(
                'section' => 'colors',
                'label' => esc_html__('Header top menu color - first', 'mida')
            )));


            // Header menu color - second
            $wp_customize->add_setting('header-menu-txt-color-second', array(
                'default' => '#ffffff',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header-menu-txt-color-second', array(
                'section' => 'colors',
                'label' => esc_html__('Header top menu color - second', 'mida')
            )));


            // Header menu color - inner
            $wp_customize->add_setting('header-menu-txt-color-inner', array(
                'default' => '#004552',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header-menu-txt-color-inner', array(
                'section' => 'colors',
                'label' => esc_html__('Header top menu color - inner pages ', 'mida')
            )));


            // Sticky header background color - first
            $wp_customize->add_setting('header-menu-sticky-bg-color-first', array(
                'default' => '#ffffff',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header-menu-sticky-bg-color-first', array(
                'section' => 'colors',
                'label' => esc_html__('Sticky header background color - first', 'mida')
            )));


            // Sticky header background color - second
            $wp_customize->add_setting('header-menu-sticky-bg-color-second', array(
                'default' => '#000000',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header-menu-sticky-bg-color-second', array(
                'section' => 'colors',
                'label' => esc_html__('Sticky header background color - second', 'mida')
            )));


            // Sticky header background color - inner
            $wp_customize->add_setting('header-menu-sticky-bg-color-inner', array(
                'default' => '#ffffff',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header-menu-sticky-bg-color-inner', array(
                'section' => 'colors',
                'label' => esc_html__('Sticky header background color - inner pages ', 'mida')
            )));


            // Button text color
            $wp_customize->add_setting('button-txt-color', array(
                'default' => '#ffffff',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'button-txt-color', array(
                'section' => 'colors',
                'label' => esc_html__('Button text color', 'mida')
            )));


            // Button text color hover
            $wp_customize->add_setting('button-txt-color-hover', array(
                'default' => '#ffffff',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'button-txt-color-hover', array(
                'section' => 'colors',
                'label' => esc_html__('Button text color on hover', 'mida')
            )));


            // Button background color
            $wp_customize->add_setting('button-bg-color', array(
                'default' => '#038A9D',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'button-bg-color', array(
                'section' => 'colors',
                'label' => esc_html__('Button background color', 'mida')
            )));


            // Button background color hover
            $wp_customize->add_setting('button-bg-color-hover', array(
                'default' => '#004552',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'button-bg-color-hover', array(
                'section' => 'colors',
                'label' => esc_html__('Button background color on hover', 'mida')
            )));


            // Header CTA button text color
            $wp_customize->add_setting('header-cta-txt-color', array(
                'default' => '#ffffff',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header-cta-txt-color', array(
                'section' => 'colors',
                'label' => esc_html__('Header CTA button text color', 'mida')
            )));


            // Header CTA button text color on hover
            $wp_customize->add_setting('header-cta-txt-color-hover', array(
                'default' => '#ffffff',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header-cta-txt-color-hover', array(
                'section' => 'colors',
                'label' => esc_html__('Header CTA button text color on hover', 'mida')
            )));


            // Header CTA button background color
            $wp_customize->add_setting('header-cta-bg-color', array(
                'default' => '#038A9D',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header-cta-bg-color', array(
                'section' => 'colors',
                'label' => esc_html__('Header CTA button background color', 'mida')
            )));


            // Header CTA button background color on hover
            $wp_customize->add_setting('header-cta-bg-color-hover', array(
                'default' => '#004552',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header-cta-bg-color-hover', array(
                'section' => 'colors',
                'label' => esc_html__('Header CTA button background color on hover', 'mida')
            )));

            
            // Footer text color
            $wp_customize->add_setting('footer-txt-color', array(
                'default' => '#004552',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer-txt-color', array(
                'section' => 'colors',
                'label' => esc_html__('Footer text color', 'mida')
            )));


            // Footer background color
            $wp_customize->add_setting('footer-bg-color', array(
                'default' => '#d6ecef',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color'
            ));

            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer-bg-color', array(
                'section' => 'colors',
                'label' => esc_html__('Footer background color', 'mida')
            )));


            /* end COLORS */
            /* ============================================================================================================================= */
            /* ============================================================================================================================= */
            /* ============================================================================================================================= */

            /* ========================================================================= */
            /*
             * HEADER
             */

            $wp_customize->add_section('header', array(
                'title' => esc_html__('Header', 'mida')
            ));


            // Header background image
            $wp_customize->add_setting('header_bg_image', array(
                'capability'        => 'edit_theme_options',
                'default'           => get_template_directory_uri().'/assets/img/bg.png',
                'sanitize_callback' => 'hbi_sanitize_image',
            ) );
            $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'header_bg_image',
                array(
                    'section' => 'header',
                    'label' => esc_html__('Header background image:', 'mida'),
                    'settings' => 'header_bg_image',
                )
            ));


            // Header second logo
            $wp_customize->add_setting('header-second-logo', array(
                'capability'        => 'edit_theme_options',
                'sanitize_callback' => 'hbi_sanitize_image',
            ) );
            $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'header-second-logo',
                array(
                    'section' => 'header',
                    'label' => esc_html__('Header second logo:', 'mida'),
                    'settings' => 'header-second-logo',
                )
            ));


            // Header inner pages logo
            $wp_customize->add_setting('header-inner-logo', array(
                'capability'        => 'edit_theme_options',
                'sanitize_callback' => 'hbi_sanitize_image',
            ) );
            $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'header-inner-logo',
                array(
                    'section' => 'header',
                    'label' => esc_html__('Header inner pages logo:', 'mida'),
                    'settings' => 'header-inner-logo',
                )
            ));


            // Enable CTA button in the header
            $wp_customize->add_setting('h_cta_btn_switcher', array(
                'default' => false,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('h_cta_btn_switcher', array(
                'section' => 'header',
                'label' => esc_html__('Enable CTA button (call-to-action).', 'mida'),
                'type' => 'checkbox'
            ));


            // Header CTA button link
            $wp_customize->add_setting('h_cta_btn_link', array(
                'default' => esc_html__('/contact-us', 'mida'),
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('h_cta_btn_link', array(
                'section' => 'header',
                'label' => esc_html__('CTA button link:', 'mida'),
                'type' => 'text'
            ));


            // Header CTA button text
            $wp_customize->add_setting('h_cta_btn_txt', array(
                'default' => esc_html__('Buy Now', 'mida'),
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('h_cta_btn_txt', array(
                'section' => 'header',
                'label' => esc_html__('CTA button text:', 'mida'),
                'type' => 'text'
            ));


            // Enable opening of CTA link in the new tab
            $wp_customize->add_setting('h_cta_link_switcher', array(
                'default' => true,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('h_cta_link_switcher', array(
                'section' => 'header',
                'label' => esc_html__('Open CTA button link in the new tab', 'mida'),
                'type' => 'checkbox'
            ));


            // Change logo height
            $wp_customize->add_setting('logo-height', array(
                'default' => '34',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('logo-height', array(
                'section' => 'header',
                'label' => esc_html__('Logo height:', 'mida'),
                'type' => 'number'
            ));


            // Sticky header
            $wp_customize->add_setting('sticky_header_switcher', array(
                'default' => false,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('sticky_header_switcher', array(
                'section' => 'header',
                'label' => esc_html__('Sticky header', 'mida'),
                'type' => 'checkbox'
            ));


            // Header background scroll
            $wp_customize->add_setting('header-bg-scroll-switcher', array(
                'default' => true,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('header-bg-scroll-switcher', array(
                'section' => 'header',
                'label' => esc_html__('Header background scroll', 'mida'),
                'type' => 'checkbox'
            ));


            // Header background overlay
            $wp_customize->add_setting('header-bg-overlay-switcher', array(
                'default' => false,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('header-bg-overlay-switcher', array(
                'section' => 'header',
                'label' => esc_html__('Disable header background overlay', 'mida'),
                'type' => 'checkbox'
            ));


            // Switcher to enable Close mobile menu after click
            $wp_customize->add_setting('h_close_mobile_menu', array(
                'default' => false,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('h_close_mobile_menu', array(
                'section' => 'header',
                'label' => esc_html__('Close mobile menu after click. Useful for one-page websites and anchor links.', 'mida'),
                'type' => 'checkbox'
            ));


            /* end HEADER */
            /* ========================================================================= */
            /*
             * FOOTER
             */

            $wp_customize->add_section('footer', array(
                'title' => esc_html__('Footer', 'mida')
            ));

            // Switcher for Copyright text
            $wp_customize->add_setting('copyright_text_switcher', array(
                'default' => false,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('copyright_text_switcher', array(
                'section' => 'footer',
                'label' => esc_html__('Disable "Copyright" text before the year', 'mida'),
                'type' => 'checkbox'
            ));

            // Custom copyright
            $wp_customize->add_setting('copyright_text', array(
                'default' => '',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('copyright_text', array(
                'section' => 'footer',
                'label' => esc_html__('Custom copyright text.', 'mida'),
                'description' => esc_html__('Leave blank to use default copyright.', 'mida'),
                'type' => 'text'
            ));


            /* end FOOTER */
            /* ========================================================================= */
            /*
             * TWEAKS
             */

            $wp_customize->add_section('tweaks', array(
                'title' => esc_html__('Tweaks', 'mida')
            ));


            // Disable post category meta text
            $wp_customize->add_setting('meta_cat_switcher', array(
                'default' => false,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('meta_cat_switcher', array(
                'section' => 'tweaks',
                'label' => esc_html__('Disable post category meta text', 'mida'),
                'type' => 'checkbox'
            ));


            // Disable date meta text
            $wp_customize->add_setting('meta_date_switcher', array(
                'default' => false,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('meta_date_switcher', array(
                'section' => 'tweaks',
                'label' => esc_html__('Disable date meta text', 'mida'),
                'type' => 'checkbox'
            ));


            // Disable post author meta text
            $wp_customize->add_setting('meta_author_switcher', array(
                'default' => false,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('meta_author_switcher', array(
                'section' => 'tweaks',
                'label' => esc_html__('Disable post author meta text', 'mida'),
                'type' => 'checkbox'
            ));


            // Disable post comments meta text
            $wp_customize->add_setting('meta_comm_switcher', array(
                'default' => false,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('meta_comm_switcher', array(
                'section' => 'tweaks',
                'label' => esc_html__('Disable post comments meta text', 'mida'),
                'type' => 'checkbox'
            ));


            // Disable post excerpt text
            $wp_customize->add_setting('post-excerpt-switcher', array(
                'default' => false,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('post-excerpt-switcher', array(
                'section' => 'tweaks',
                'label' => esc_html__('Disable post excerpt', 'mida'),
                'type' => 'checkbox'
            ));


            // Blog sidebar position
            $wp_customize->add_setting('blog-sidebar-position-switcher', array(
                'default' => false,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('blog-sidebar-position-switcher', array(
                'section' => 'tweaks',
                'label' => esc_html__('Change sidebar position to left', 'mida'),
                'type' => 'checkbox'
            ));


            // Header menu position
            $wp_customize->add_setting('header-menu-position-switcher', array(
                'default' => false,
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_text_field'
            ));

            $wp_customize->add_control('header-menu-position-switcher', array(
                'section' => 'tweaks',
                'label' => esc_html__('Change header menu position to center', 'mida'),
                'type' => 'checkbox'
            ));


            /* end TWEAKS */
            /* ========================================================================= */


            /* -----------------------------*/
            /* end Customize Settings */
            /* -----------------------------*/
        }
    }


    // Setup the Theme Customizer settings and controls.
    add_action('customize_register', array('Mida_Customize', 'register'));

}