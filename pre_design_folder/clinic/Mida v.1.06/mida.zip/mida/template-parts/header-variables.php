:root {
--accent-color: <?php echo esc_html(get_theme_mod('accent-color', '#038A9D')); ?>;
--accent-color-hover: <?php echo esc_html(get_theme_mod('accent-color-hover', '#004552')); ?>;
--global-txt-color: <?php echo esc_html(get_theme_mod('global-txt-color', '#004552')); ?>;

--button-txt-color: <?php echo esc_html(get_theme_mod('button-txt-color', '#ffffff')); ?>;
--button-txt-color-hover: <?php echo esc_html(get_theme_mod('button-txt-color-hover', '#ffffff')); ?>;
--button-bg-color: <?php echo esc_html(get_theme_mod('button-bg-color', '#038A9D')); ?>;
--button-bg-color-hover: <?php echo esc_html(get_theme_mod('button-bg-color-hover', '#004552')); ?>;

--header-menu-txt-color-first: <?php echo esc_html(get_theme_mod('header-menu-txt-color-first', '#004552')); ?>;
--header-menu-txt-color-second: <?php echo esc_html(get_theme_mod('header-menu-txt-color-second', '#ffffff')); ?>;
--header-menu-txt-color-inner: <?php echo esc_html(get_theme_mod('header-menu-txt-color-inner', '#004552')); ?>;

--header-menu-sticky-bg-color-first: <?php echo esc_html(get_theme_mod('header-menu-sticky-bg-color-first', '#ffffff')); ?>;
--header-menu-sticky-bg-color-second: <?php echo esc_html(get_theme_mod('header-menu-sticky-bg-color-second', '#000000')); ?>;
--header-menu-sticky-bg-color-inner: <?php echo esc_html(get_theme_mod('header-menu-sticky-bg-color-inner', '#ffffff')); ?>;

--header-cta-txt-color: <?php echo esc_html(get_theme_mod('header-cta-txt-color', '#ffffff')); ?>;
--header-cta-txt-color-hover: <?php echo esc_html(get_theme_mod('header-cta-txt-color-hover', '#ffffff')); ?>;
--header-cta-bg-color: <?php echo esc_html(get_theme_mod('header-cta-bg-color', '#038A9D')); ?>;
--header-cta-bg-color-hover: <?php echo esc_html(get_theme_mod('header-cta-bg-color-hover', '#004552')); ?>;

--header-title-txt-color: <?php echo esc_html(get_theme_mod('header-title-txt-color', '#004552')); ?>;
--header-bg-overlay-color: <?php echo esc_html(get_theme_mod('header-bg-overlay-color', '#c1dce0')); ?>;
--logo-height: <?php echo esc_html(get_theme_mod('logo-height', '34')) . 'px'; ?>;

--footer-txt-color: <?php echo esc_html(get_theme_mod('footer-txt-color', '#004552')); ?>;
--footer-bg-color: <?php echo esc_html(get_theme_mod('footer-bg-color', '#d6ecef')); ?>;
}