<?php
echo '<h5 class="m-0">' . esc_html(get_bloginfo('name')) . '</h5>';