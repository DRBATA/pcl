<div class="col-lg p-0 blog-tile">
    <article <?php post_class(); ?> id="post-<?php the_ID(); ?>">
        <div class="blog-tile-<?php if(has_post_thumbnail()) {echo esc_attr('empty-');}?>placeholder">
            <a href="<?php echo esc_url(get_the_permalink()) ?>"><?php
                get_template_part('template-parts/featured-media');
                ?></a>
        </div>
        <div class="blog-tile-content">
            <?php
            get_template_part('template-parts/blog-entry-header');
            ?>
        </div>
    </article>
</div>