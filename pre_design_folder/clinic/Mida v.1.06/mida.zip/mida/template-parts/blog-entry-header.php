<?php
/**
 * Displays the post header
 * @since Mida 1.2
 */
?>
<header class="entry-header">
    <a href="<?php echo esc_url(get_the_permalink()) ?>" class="entry-title-link"><?php
        the_title('<h5 class="entry-title">', '</h5>'); ?></a><?php
        if (true === apply_filters('mida_show_categories_in_entry_header', true) && has_category()) { ?>
            <div class="entry-categories">
                <span class="screen-reader-text"><?php esc_html_e('Categories', 'mida'); ?></span>
                <div class="entry-categories-inner">
                    <?php the_category(', '); ?>
                </div>
            </div>
            <?php
        } ?>
        <div class="entry-excerpt"><?php the_excerpt(); ?></div>
        <div class="entry-meta"><?php mida_the_post_meta(get_the_ID(), 'single-top'); ?></div>
</header>