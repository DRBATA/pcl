<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=<?php bloginfo('charset'); ?>">
    <meta id="siteViewport" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open();
$template_first = is_page_template('page-templates/template-full-width-page-without-header-title.php');
$template_second = is_page_template('page-templates/template-full-width-page-without-header-title-second.php');
?>
<nav id="pr-nav" class="primary-menu navbar navbar-expand-lg navbar-dark<?php
if ($template_first){
    echo ' header-nav-txt-first-desktop';
}
if ($template_second){
    echo ' header-nav-txt-second-desktop';
}
if (!$template_first && !$template_second){
    echo ' header-nav-txt-inner-desktop';
}
?>">
    <div class="container-fluid primary-menu-inner">
        <div class="top-wrap">
            <?php

            echo '<a class="custom-logo-link" href="' . esc_url(home_url()) . '">';

            if ($template_first) {
                if (has_custom_logo()) {
                    the_custom_logo();
                   } else {
                    get_template_part('template-parts/header-sitename');
                }
            }

            if ($template_second) {
                if (get_theme_mod( 'header-second-logo' )) {
                    $themelogo = get_theme_mod('header-second-logo');
                    $themelogo_size = getimagesize($themelogo);
                    $themelogo_width = $themelogo_size[0];
                    $themelogo_height = $themelogo_size[1];
                    ?><img width="<?php echo esc_attr($themelogo_width);?>" height="<?php echo esc_attr($themelogo_height);?>" src='<?php echo esc_url($themelogo); ?>' alt='<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>' class="custom-logo style-svg" decoding="async"><?php
                } elseif (has_custom_logo()) {
                    the_custom_logo();
                } else {
                    get_template_part('template-parts/header-sitename');
                }
            }

            if (!$template_first && !$template_second) {
                if (get_theme_mod( 'header-inner-logo' )) {
                    $themelogo = get_theme_mod('header-inner-logo');
                    $themelogo_size = getimagesize($themelogo);
                    $themelogo_width = $themelogo_size[0];
                    $themelogo_height = $themelogo_size[1];
                    ?><img width="<?php echo esc_attr($themelogo_width);?>" height="<?php echo esc_attr($themelogo_height);?>" src='<?php echo esc_url($themelogo); ?>' alt='<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>' class="custom-logo style-svg" decoding="async"><?php
                } elseif (has_custom_logo()) {
                    the_custom_logo();
                } else {
                    get_template_part('template-parts/header-sitename');
                }
            }

            echo '</a>';

            ?>
            <button id="mobile-toggle" class="navbar-toggler animate-button collapsed" type="button"
                    data-toggle="collapse" data-target="#navbarColor01"
                    aria-controls="navbarColor01" aria-expanded="false" aria-label="<?php esc_attr_e('Toggle navigation', 'mida'); ?>">
                <span id="m-tgl-icon" class="animated-icon1"><span></span><span></span></span>
            </button>
        </div>
        <div class="collapse navbar-collapse justify-content-end" id="navbarColor01">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'menu_id' => 'primary-menu',
                'depth' => 3,
                'container' => false,
                'menu_class' => 'navbar-nav',
                'fallback_cb' => 'WP_Bootstrap_Navwalker::fallback',
                'walker' => new WP_Bootstrap_Navwalker()
            ));

            if (get_theme_mod('h_cta_btn_switcher', false)) {

                $h_cta_btn_link = get_theme_mod('h_cta_btn_link');
                $h_cta_btn_txt = get_theme_mod('h_cta_btn_txt');

                ?><div class="header-cta"><a href="<?php if ('' == $h_cta_btn_link) {
                    echo esc_html__('/contact-us', 'mida');
                } else {
                    echo esc_html($h_cta_btn_link);
                } ?>"<?php
                if (get_theme_mod('h_cta_link_switcher', true)) {
                    ?> target="_blank"<?php } ?>><div class="d-inline-block elementor-button-link elementor-button elementor-size-md"><?php
                if ('' == $h_cta_btn_txt) {
                    echo esc_html__('Contact Us', 'mida');
                } else {
                    echo esc_html($h_cta_btn_txt);
                } ?></div></a></div><?php

            }
            ?>
        </div>
    </div>
</nav>
<?php
if (!$template_first && !$template_second) { ?>
<header id="main-header" class="main-header-bg" style="background-image: url(<?php if (get_theme_mod( 'header_bg_image' )) : echo get_theme_mod( 'header_bg_image'); else: echo get_template_directory_uri().'/assets/img/bg.png'; endif; ?>)">
    <div class="container inner-header">
        <div class="title-wrap">
            <h1 class="header-title"><?php
                if (mida_is_product()) {
                    the_title();
                } elseif (mida_is_shop()) {
                    woocommerce_page_title();
                } elseif (is_singular()) {
                    single_post_title();
                } elseif (is_404()) {
                    esc_html_e('404 NOT FOUND', 'mida');
                } elseif (is_search()) {
                    esc_html_e('Search', 'mida');
                } elseif (is_archive() && !have_posts()) {
                    esc_html_e('Nothing Found', 'mida');
                } elseif (is_archive()) {
                    the_archive_title();
                } elseif (is_tax()) {
                    single_term_title();
                } else {
                    $site_description = get_bloginfo('description', 'display');
                    $site_name = get_bloginfo('name');
                    //for home page
                    if (is_home() || is_front_page()):
                        echo esc_html($site_name);
                        if ($site_description) {
                            echo '<span class="h-site-description">';
                            echo esc_html($site_description);
                            echo '</span>'; }
                    endif;
                    // for other post pages
                    if (!(is_home()) && !is_404()):
                        the_title();
                        echo ' | ';
                        echo esc_html($site_name);
                    endif;
                } ?></h1><?php
            if (function_exists('bcn_display')) { ?>
                <div class="breadcrumbs" typeof="BreadcrumbList" vocab="https://schema.org/">
                    <?php bcn_display(); ?>
                </div>
                <?php
            } ?>
        </div>
    </div>
</header>
<?php
}