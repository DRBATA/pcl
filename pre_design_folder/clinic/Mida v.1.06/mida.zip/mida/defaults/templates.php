<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('DuckThemes_Templates_Map')) {
    final class DuckThemes_Templates_Map
    {
        // ===========================
        // START CONSTANTS
        // ===========================

        public const DuckThemes_Theme_Domain = 'mida';
        private const DuckThemes_Theme_VER_KEY = 'v1-eaxzoXctHRdg';
        private const DuckThemes_Theme_SCREENSHOT_FOLDER = 'v1';

        // ===========================
        // END CONSTANTS
        // ===========================

        public static function get_templates_map_array()
        {
            return [
                'templates' => [

                    // ===========================
                    // START TEMPLATES
                    // ===========================

                    'medical-diagnostic-center' => [
                        'title' => esc_html__('Medical Diagnostic Center', DuckThemes_Templates_Map::DuckThemes_Theme_Domain),
                        'version-key' => self::DuckThemes_Theme_VER_KEY,
                        'screenshot-folder' => self::DuckThemes_Theme_SCREENSHOT_FOLDER,
                    ],
                    'plastic-surgery-clinic' => [
                        'title' => esc_html__('Plastic Surgery Clinic', DuckThemes_Templates_Map::DuckThemes_Theme_Domain),
                        'version-key' => self::DuckThemes_Theme_VER_KEY,
                        'screenshot-folder' => self::DuckThemes_Theme_SCREENSHOT_FOLDER,
                    ],
                    'expert-diagnostic-services' => [
                        'title' => esc_html__('Expert Diagnostic Services', DuckThemes_Templates_Map::DuckThemes_Theme_Domain),
                        'version-key' => self::DuckThemes_Theme_VER_KEY,
                        'screenshot-folder' => self::DuckThemes_Theme_SCREENSHOT_FOLDER,
                    ],
                    'transform-your-appearance' => [
                        'title' => esc_html__('Transform Your Appearance', DuckThemes_Templates_Map::DuckThemes_Theme_Domain),
                        'version-key' => self::DuckThemes_Theme_VER_KEY,
                        'screenshot-folder' => self::DuckThemes_Theme_SCREENSHOT_FOLDER,
                    ],
                    'about-us' => [
                        'title' => esc_html__('About Us', DuckThemes_Templates_Map::DuckThemes_Theme_Domain),
                        'version-key' => self::DuckThemes_Theme_VER_KEY,
                        'screenshot-folder' => self::DuckThemes_Theme_SCREENSHOT_FOLDER,
                    ],
                    'treatments' => [
                        'title' => esc_html__('Treatments', DuckThemes_Templates_Map::DuckThemes_Theme_Domain),
                        'version-key' => self::DuckThemes_Theme_VER_KEY,
                        'screenshot-folder' => self::DuckThemes_Theme_SCREENSHOT_FOLDER,
                    ],
                    'our-gallery' => [
                        'title' => esc_html__('Before and After',DuckThemes_Templates_Map::DuckThemes_Theme_Domain),
                        'version-key' => self::DuckThemes_Theme_VER_KEY,
                        'screenshot-folder' => self::DuckThemes_Theme_SCREENSHOT_FOLDER,
                    ],
                    'our-team' => [
                        'title' => esc_html__('Our Doctors', DuckThemes_Templates_Map::DuckThemes_Theme_Domain),
                        'version-key' => self::DuckThemes_Theme_VER_KEY,
                        'screenshot-folder' => self::DuckThemes_Theme_SCREENSHOT_FOLDER,
                    ],
                    'contact-us' => [
                        'title' => esc_html__('Contact Us', DuckThemes_Templates_Map::DuckThemes_Theme_Domain),
                        'version-key' => self::DuckThemes_Theme_VER_KEY,
                        'screenshot-folder' => self::DuckThemes_Theme_SCREENSHOT_FOLDER,
                    ],


                    // ===========================
                    // END TEMPLATES
                    // ===========================

                ]
            ];
        }
    }
}