<?php
/*
 * Generates inline JS to set viewports.
 */
if (!function_exists('mida_get_viewport_script')) {
    function mida_get_viewport_script()
    {
        ob_start();
        echo "
    if (screen.width >= 1535 && screen.width < 2561) { 
        let mvp = document.getElementById('siteViewport');
        mvp.setAttribute('content','width=1920');
    }
    if (screen.width > 767 && screen.width < 1535) {
        let mvp = document.getElementById('siteViewport');
        mvp.setAttribute('content','width=1700');
    }
    ";

        // Close mobile menu after click
        if (get_theme_mod('h_close_mobile_menu', false)) {
            echo "jQuery(document).ready(function () {jQuery('.menu-item:not(".'".dropdown")'."').on('click', function () {
        if (window.matchMedia('(max-width: 1199px)').matches) {
            jQuery('#mobile-toggle').click();
        }});});";
        }

        return ob_get_clean();
    }
}