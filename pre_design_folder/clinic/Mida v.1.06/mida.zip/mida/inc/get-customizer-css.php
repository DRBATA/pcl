<?php
/*
 * Generates inline CSS from Customizer settings.
 */
if (!function_exists('mida_get_customizer_css')) {
    function mida_get_customizer_css()
    {
        ob_start();

        get_template_part('template-parts/header-variables');

        if (get_theme_mod('meta_cat_switcher', false)) {
            echo '.entry-categories {display: none;}';
        }

        if (get_theme_mod('meta_author_switcher', false)) {
            echo '.post-author {display: none;}';
        }

        if (get_theme_mod('meta_date_switcher', false)) {
            echo '.blog-tile .post-date {display: none;}';
        }

        if (get_theme_mod('meta_comm_switcher', false)) {
            echo '.post-comment-link {display: none;}';
        }

        if (get_theme_mod('meta_pr_cat_switcher', false)) {
            echo '.product_meta .posted_in {display: none;}';
        }

        if (get_theme_mod('header-bg-overlay-switcher', false)) {
            echo '#main-header:before {display: none;}';
        }

        if (get_theme_mod('post-excerpt-switcher', false)) {
            echo ':root {--blog-tile-excerpt-display: none;}';
        }

        if (get_theme_mod('header-bg-scroll-switcher', true)) {
            echo '#main-header {background-attachment: fixed;}';
        }

        if (get_theme_mod('blog-sidebar-position-switcher', false)) {
            echo ':root{--blog-sidebar-position-flex-flow: row-reverse; --blog-sidebar-position-margin: 0 20px 0 0;}';
        }

        if (get_theme_mod('header-menu-position-switcher', false)) {
            echo ':root{--header-menu-position: center}';
        }

        return ob_get_clean();
    }
}