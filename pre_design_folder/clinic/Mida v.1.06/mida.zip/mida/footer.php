<footer id="site-footer" role="contentinfo">

    <div class="footer-bg">

        <div class="footer-inner container-xl">

            <?php get_template_part('template-parts/footer-widgets'); ?>

            <div class="footer-bottom">

                <div class="footer-credits">

                    <p class="footer-copyright"><?php if (false == get_theme_mod('copyright_text_switcher')) {
                            echo 'Copyright ';
                        } ?>&copy;<?php
                        echo date_i18n(
                        /* translators: Copyright date format, see https://www.php.net/date */
                            esc_html_x('Y ', 'copyright date format', 'mida')
                        );
                        $cop_txt = get_theme_mod('copyright_text');
                        if ('' == $cop_txt) {
                            bloginfo('name');
                            esc_html_e('. All rights reserved. ', 'mida');
                        } else {
                            echo wp_kses($cop_txt, 'regular');
                        } ?>

                    </p><!-- .footer-copyright -->

                </div><!-- .footer-credits -->

            </div><!-- .footer-bottom  -->

        </div><!-- .footer-inner -->

    </div>

</footer><!-- #site-footer -->

<?php wp_footer(); ?>

</body>
</html>