<?php
/**
 * Template Name: Blog 1 Column with Sidebar
 */
get_header(); ?>
    <main id="site-content" class="blog flex-grow-1" role="main">
        <div class="container<?php if (!is_active_sidebar('blog-sidebar')) { echo ' container-narrow'; }?>">
            <?php if (is_active_sidebar('blog-sidebar')) { ?>
                <div class="row blog-general">
                    <div class="col-lg-9 blog-main-content">
                        <?php
                        set_query_var('columns', 1);
                        get_template_part('template-parts/blog-grid');
                        ?>
                    </div>
                    <div class="col-lg-3 blog-sidebar">
                        <div class="blog-sidebar-inner">
                            <div class="blog-sidebar-widgets">
                                <?php dynamic_sidebar('blog-sidebar'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } else {
                set_query_var('columns', 1);
                get_template_part('template-parts/blog-grid');
            } ?>
        </div>
    </main>
<?php get_footer();