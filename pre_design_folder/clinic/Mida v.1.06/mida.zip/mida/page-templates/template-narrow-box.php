<?php
/**
 * Template Name: Narrow Box
 * The template for displaying pages without Header Title
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 * @since Mida 1.0
 */
get_header();
get_template_part('template-parts/layout-narrow-box');
get_footer();