<?php
/**
 * Template Name: Fullwidth + Second Top Menu + Default Footer
 * The template for displaying pages without Header Title with white menu on desktop and default footer
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 * @since Mida 1.0
 */
get_header();
get_template_part('template-parts/layout-full-width');
get_footer();