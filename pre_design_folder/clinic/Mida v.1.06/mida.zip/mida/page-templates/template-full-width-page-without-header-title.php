<?php
/**
 * Template Name: Fullwidth + First Top Menu + Default Footer
 * The template for displaying pages without Header Title
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 * @since Mida 1.0
 */
get_header();
get_template_part('template-parts/layout-full-width');
get_footer();