<?php


namespace Gutencon\Blocks;
defined('ABSPATH') OR exit;


class Countdown{

	protected $name = 'countdown';

	public function __construct(){
		add_action('init', array( $this, 'init_handler' ));
	}

	public function init_handler(){
		register_block_type('gutencon/'.$this->name, array(
			'editor_script' => 'gutencon_common_js',
			'editor_style' => 'gutencon_common_css'
		));
	}

}

new Countdown;