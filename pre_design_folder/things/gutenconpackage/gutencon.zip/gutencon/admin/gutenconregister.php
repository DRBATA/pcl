<?php
if (!defined('ABSPATH')) {
	wp_die();
}
echo '<style>
.wrap{background:white;max-width: 900px;margin: 2.5em auto;border: 1px solid #dbdde2;box-shadow: 0 10px 20px #ececec; text-align:center}
.wrap .notice, .wrap .error{display:none}
.wrap h2{font-size:2em; margin-bottom:1em; font-weight:bold}
.gc-introtext{font-size:15px; margin: 0 auto 50px auto; padding: 0 50px}
.gc-intro-form{margin-bottom:50px;display: flex;justify-content: center; overflow:hidden}
.wrap h1{text-align: left;padding: 15px 20px;margin: -1px -1px 10px -1px;font-size: 13px;font-weight: bold;text-transform: uppercase;box-shadow: 0 3px 8px rgb(0 0 0 / 5%);}
.gc-padd {padding:25px}
.gc-intro-form input {padding: 10px 15px;width: 30%;margin-right: 20px;float: left;}
.gc-intro-form .button-large{font-size:17px; font-weight: bold}
.gc-intro-wrapper{padding: 30px; border: 1px solid #eee}
.gc-intro-wrapper p{font-size:15px;  margin: 0 0 1em 0}
.gc-intro-wrapper p.about-description{font-size:18px}
</style>';
$gc_options = get_option('GC_Key');
$cc_username = isset($gc_options['cc_username']) ? $gc_options['cc_username'] : '';
$cc_purchase_code = isset($gc_options['cc_purchase_code']) ? $gc_options['cc_purchase_code'] : '';

require_once('lhelper.php');
// Create a new LicenseBoxAPI helper class.
$lbapi = new GCLicenseBoxAPI();

// Performs background license check, pass TRUE as 1st parameter to perform periodic verifications only.
$registeredlicense = false;
if ($cc_username && $cc_purchase_code) {
	$lb_verify_res = $lbapi->verify_license(true, sanitize_text_field($cc_purchase_code), sanitize_text_field($cc_username));
	if (!empty($lb_verify_res['status'])) {
		$registeredlicense = true;
	}
}

$lb_deactivate_res = $activationmessage = $deactivationmessage = $lb_activate_res = null;

if (!empty($_POST['client_name']) && !empty($_POST['license_code'])) {
	check_admin_referer('lb_update_license', 'lb_update_license_sec');
	$licode = sanitize_text_field(trim($_POST['license_code']));
	$liuser = sanitize_text_field(trim($_POST['client_name']));
	$lb_verify_res = $lbapi->verify_license(false, $licode, $liuser);

	if (empty($lb_verify_res['status'])) {
		$lb_activate_res = $lbapi->activate_license($licode, $liuser, false);
	}

	if (!empty($lb_activate_res['status']) || !empty($lb_verify_res['status'])) {
		$gc_options = array('cc_username' => $liuser, 'cc_purchase_code' => $licode);
		update_option('GC_Key', $gc_options);
		$cc_username = $liuser;
		$cc_purchase_code = $licode;
		$registeredlicense = true;
	} else {
		$activationmessage = $lb_activate_res['message'];
		$registeredlicense = false;
	}
}
if (!empty($_POST['lb_deactivate'])) {
	if (empty($cc_purchase_code)) {
		$cc_purchase_code = trim($_POST['deactivate_license_code']);
	}
	if (empty($cc_username)) {
		$cc_username = trim($_POST['deactivate_client_name']);
	}
	check_admin_referer('lb_deactivate_license', 'lb_deactivate_license_sec');
	$lb_deactivate_res = $lbapi->deactivate_license(sanitize_text_field($cc_purchase_code), sanitize_text_field($cc_username));
	if (!empty($lb_deactivate_res['status'])) {
		delete_option('GC_Key');
		$cc_purchase_code = $cc_username = '';
		$registeredlicense = false;
	} else {
		$deactivationmessage = $lb_deactivate_res['message'];
	}
}
echo '<div class="wrap"><h1>' . esc_html__('Register your copy', 'gutencon') . '</h1><div class="gc-padd">';
?>
<h2><?php esc_html_e('Welcome to Gutencon', 'gutencon'); ?></h2>
<p class="gc-introtext">
	<?php if ($registeredlicense == true) : ?>
	<?php esc_html_e("Plugin is registered on your site! ", "gutencon"); ?>
	<?php if (!function_exists('envato_market')) : ?>
		<?php esc_html_e("If you need automatic updates of all your Envato plugins, install and activate Envato Market plugin from ", "gutencon"); ?>
		<a href="<?php echo admin_url('admin.php?page=gutenconbonus'); ?>"><?php esc_html_e("Bonus Section", "gutencon"); ?></a>. <?php esc_html_e("If you have broken styles of blocks on your site, disable conditional style loading in global settings of plugin", "gutencon"); ?>

	<?php endif; ?>
<?php else : ?>
	<?php esc_html_e("Please, activate your license to get support, updates, ready presets and bonus addons", "gutencon"); ?>
	<a href="https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code-" target="_blank"><?php esc_html_e("How to find purchase code", "gutencon"); ?></a>
<?php endif; ?>
</p>
<div class="gc-intro-wrapper">
	<?php if (!$registeredlicense) : ?>
		<?php if (!empty($deactivationmessage)) : ?>
			<p style="color: red; clear:both"><?php echo esc_attr($deactivationmessage); ?></p>
		<?php endif; ?>
		<?php if (!empty($activationmessage)) : ?>
			<p style="color: red; clear:both"><?php echo esc_attr($activationmessage); ?></p>
			<?php if (stripos($activationmessage, 'License is already active on maximum') === 0 && $licode && $liuser) : ?>
				<style>
					.gc-activate-form {
						display: none;
					}
				</style>
				<p>
					<span><strong style="color:red"><?php esc_html_e("One license can be active only on one site.", "gutencon"); ?></strong></span><br>
				</p>
				<p style="clear:both;color:green"><?php esc_html_e("You can use form below to deactivate your license on all of your existed activated sites.", "gutencon"); ?>  </p>
				<div class="gc-intro-form">
					<form action="" method="post">
						<?php wp_nonce_field('lb_deactivate_license', 'lb_deactivate_license_sec'); ?>

						<input type="text" name="deactivate_client_name" size="50" placeholder="<?php esc_html_e("Codecanyon Username", "gutencon"); ?>" required value="<?php echo esc_attr($cc_username); ?>">
						<input type="text" name="deactivate_license_code" size="50" placeholder="<?php esc_html_e("Enter Codecanyon Purchase Code", "gutencon"); ?>" required value="<?php echo esc_attr($cc_purchase_code); ?>">
						<input type="hidden" name="lb_deactivate" value="yes">
						<input type="submit" value="<?php esc_html_e("Deactivate", "gutencon"); ?>" class="button button-large button-primary gc-large-button">
					</form>
				</div>
			<?php endif; ?>
		<?php endif; ?>
		<div class="gc-intro-form gc-activate-form">
			<form action="" method="post">
				<?php wp_nonce_field('lb_update_license', 'lb_update_license_sec'); ?>
				<input type="text" name="client_name" size="50" placeholder="<?php esc_html_e("Codecanyon Username", "gutencon"); ?>" required value="<?php echo esc_attr($cc_username); ?>">
				<input type="text" name="license_code" size="50" placeholder="<?php esc_html_e("Enter Codecanyon Purchase Code", "gutencon"); ?>" required value="<?php echo esc_attr($cc_purchase_code); ?>">
				<input type="submit" value="<?php esc_html_e("Submit", "gutencon"); ?>" class="button button-large button-primary gc-large-button">
			</form>
		</div>
	<?php else : ?>
		<?php if (!empty($deactivationmessage)) : ?>
			<p style="color: red; clear:both"><?php echo esc_attr($deactivationmessage); ?></p>
		<?php endif; ?>
		<p class="about-description"><span class="dashicons dashicons-yes"></span><?php esc_html_e("Registration Complete! You have full access to plugin data now.", "gutencon"); ?></p>
		<div class="clear"></div>
		<p><?php esc_html_e("Next license is Active - ", "gutencon"); ?><span style="color: green"><?php echo esc_attr($cc_purchase_code); ?></span></p>
		<p>
			<span><strong style="color:red"><?php esc_html_e("One license can be active only on one site.", "gutencon"); ?></strong><br></span><br>
		</p>
	<?php endif ?>
</div>


</div>
</div>