<?php

include_once MARITY_INC_ROOT_DIR . '/welcome/class-marity-welcome-page.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
