<?php

// Include logo
marity_template_part( 'header', 'templates/parts/logo' );

// Include main navigation
marity_template_part( 'header', 'templates/parts/navigation' );
