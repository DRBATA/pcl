<?php
// Hook to include additional content before page header
do_action( 'marity_action_before_page_header' );
?>
<header id="qodef-page-header" <?php marity_class_attribute( apply_filters( 'marity_filter_header_class', array(), 'default' ) ); ?> role="banner">
	<?php
	// Hook to include additional content before page header inner
	do_action( 'marity_action_before_page_header_inner' );
	?>
	<div id="qodef-page-header-inner" <?php marity_class_attribute( apply_filters( 'marity_filter_header_inner_class', array(), 'default' ) ); ?>>
		<?php

        do_action( 'marity_action_header_inner_start' );

		// Include module content template
		echo apply_filters( 'marity_filter_header_content_template', marity_get_template_part( 'header', 'templates/header-content' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

        do_action( 'marity_action_header_inner_end' );
		?>
	</div>
	<?php
	// Hook to include additional content after page header inner
	do_action( 'marity_action_after_page_header_inner' );
	?>
</header>
