<?php

include_once MARITY_INC_ROOT_DIR . '/content/helper.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
