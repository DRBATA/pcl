<?php

if ( ! function_exists( 'marity_load_page_mobile_header' ) ) {
	/**
	 * Function which loads page template module
	 */
	function marity_load_page_mobile_header() {
		// Include mobile header template
		echo apply_filters( 'marity_filter_mobile_header_template', marity_get_template_part( 'mobile-header', 'templates/mobile-header' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	add_action( 'marity_action_page_header_template', 'marity_load_page_mobile_header' );
}

if ( ! function_exists( 'marity_register_mobile_navigation_menus' ) ) {
	/**
	 * Function which registers navigation menus
	 */
	function marity_register_mobile_navigation_menus() {
		$navigation_menus = apply_filters( 'marity_filter_register_mobile_navigation_menus', array( 'mobile-navigation' => esc_html__( 'Mobile Navigation', 'marity' ) ) );

		if ( ! empty( $navigation_menus ) ) {
			register_nav_menus( $navigation_menus );
		}
	}

	add_action( 'marity_action_after_include_modules', 'marity_register_mobile_navigation_menus' );
}
