<a class="qodef-mobile-header-opener" href="#">
    <?php marity_render_svg_icon( 'menu-open', 'qodef--initial' ); ?>
    <?php marity_render_svg_icon( 'menu-close' ); ?>
</a>
