<?php

// Include mobile logo
marity_template_part( 'mobile-header', 'templates/parts/mobile-logo' );

// Include mobile navigation opener
marity_template_part( 'mobile-header', 'templates/parts/mobile-navigation-opener' );

// Include mobile navigation
marity_template_part( 'mobile-header', 'templates/parts/mobile-navigation' );
