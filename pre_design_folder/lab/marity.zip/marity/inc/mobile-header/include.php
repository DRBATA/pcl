<?php

include_once MARITY_INC_ROOT_DIR . '/mobile-header/helper.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
