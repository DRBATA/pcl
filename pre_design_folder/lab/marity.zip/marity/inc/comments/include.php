<?php

include_once MARITY_INC_ROOT_DIR . '/comments/helper.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
