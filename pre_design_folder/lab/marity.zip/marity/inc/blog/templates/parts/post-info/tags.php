<?php
$tags = get_the_tags();

if ( $tags ) { ?>
    <div class="qodef-e-tags-holder">
        <?php
        the_tags( '', '' ); ?>
    </div>
<?php } ?>
