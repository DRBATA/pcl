<?php
$additional_info_enabled  = marity_get_post_value_through_levels( 'qodef_blog_list_enable_additional_info' ) !== 'no';
?>

<article <?php post_class( 'qodef-blog-item qodef-e' ); ?>>
	<div class="qodef-e-inner">
		<?php
		// Include post media
		marity_template_part( 'blog', 'templates/parts/post-info/media' );
		?>
		<div class="qodef-e-content">
			<div class="qodef-e-top-holder">
				<div class="qodef-e-info">
					<?php
					// Include post category info
					marity_template_part( 'blog', 'templates/parts/post-info/categories' );
					?>
				</div>
			</div>
			<div class="qodef-e-text">
				<?php
				// Include post title
				marity_template_part( 'blog', 'templates/parts/post-info/title', '', array( 'title_tag' => 'h2' ) );

                if ( $additional_info_enabled ) {
                    // Include post excerpt
                    marity_template_part('blog', 'templates/parts/post-info/excerpt');
                }
                ?>
                <div class="qodef-e-about-info">
                    <?php
                    // Include post date info
                    marity_template_part( 'blog', 'templates/parts/post-info/author' );

                    // Include post date info
                    marity_template_part( 'blog', 'templates/parts/post-info/date' );

                    // Hook to include additional content after blog single content
                    do_action( 'marity_action_after_blog_single_content' );
                    ?>
                </div>
			</div>

            <?php

            if ( $additional_info_enabled ) {
                ?>
                <div class="qodef-e-bottom-holder">
                    <div class="qodef-e-left">
                        <?php
                        // Include post author info
                        marity_template_part( 'blog', 'templates/parts/post-info/tags' );
                        ?>
                    </div>
                    <div class="qodef-e-right qodef-e-info">
                        <?php
                        // Include post comments info
                        marity_template_part( 'blog', 'templates/parts/post-info/comments' );
                        ?>
                    </div>
                </div>
            <?php
            }
            ?>
		</div>
	</div>
</article>
