<?php

	$time_reading = '';

	if (  marity_is_installed( 'core' ) ) {
		$time_reading = marity_core_content_estimated_reading_time( get_the_content() );
	}

	$meta_time_reading = get_post_meta( get_the_ID(), 'qodef_blog_time_reading', true );

	if ( '' !== $meta_time_reading ) {
		$time_reading =  $meta_time_reading;
	}

	if ( '' !== $time_reading ) { ?>
		<div class="qodef-e-info-item qodef-e-info-time-reading">
			<span class="qodef-e-info-time-reading-item">
				<?php echo esc_html($time_reading) ?>
				<?php esc_html_e( ' read', 'marity' ); ?>
			</span>
		</div>
	<?php
	}
?>

