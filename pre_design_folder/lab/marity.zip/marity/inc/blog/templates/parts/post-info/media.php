<div class="qodef-e-media">
	<?php
	switch ( get_post_format() ) {
		case 'gallery':
			marity_template_part( 'blog', 'templates/parts/post-format/gallery' );
			break;
		case 'video':
			marity_template_part( 'blog', 'templates/parts/post-format/video' );
			break;
		case 'audio':
			marity_template_part( 'blog', 'templates/parts/post-format/audio' );
			break;
		default:
			marity_template_part( 'blog', 'templates/parts/post-info/image' );
			break;
	}
	?>
</div>
