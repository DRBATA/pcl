<?php
$link_url_meta  = get_post_meta( get_the_ID(), 'qodef_post_format_link', true );
$link_url       = ! empty( $link_url_meta ) ? $link_url_meta : get_the_permalink();
$link_text_meta = get_post_meta( get_the_ID(), 'qodef_post_format_link_text', true );
$link_image     = get_post_meta( get_the_ID(), 'qodef_post_format_link_image', true );

if ( ! empty( $link_url ) ) {
	$link_text = ! empty( $link_text_meta ) ? $link_text_meta : get_the_title();
	$title_tag = isset( $title_tag ) && ! empty( $title_tag ) ? $title_tag : 'h5';
	?>
    <div class="qodef-inner-wrapper">
        <div class="qodef-e-background">
            <?php
            if ( ! empty( $link_image ) ) {
                echo wp_kses_post( wp_get_attachment_image( $link_image, 'full' ) );
            } elseif ( has_post_thumbnail() ) {
                the_post_thumbnail( 'full' );
            }
            ?>
        </div>
        <div class="qodef-e-link">
            <<?php echo marity_escape_title_tag( $title_tag ); ?> class="qodef-e-link-text"><?php echo esc_html( $link_text ); ?></<?php echo marity_escape_title_tag( $title_tag ); ?>>
            <a itemprop="url" class="qodef-e-link-url" href="<?php echo esc_url( $link_url ); ?>" target="_blank"></a>
        </div>
    </div>
<?php } ?>
