<?php

    $categories = get_the_category();
    $category_color = '';
    $category_link = '';

    foreach ( $categories as $category ) {
        if (  marity_is_installed( 'core' ) ) {
            $category_color = qode_framework_get_option_value( 'category', 'taxonomy', 'qodef_post_category_color', '', $category->term_id );
        }
        $link = get_term_link( $category->term_id, 'category' );
        if ('' === $category_color) {
            $category_color = '#0e202a';
        }
    ?>
        <a class="qodef-e-category-item" href="<?php echo esc_url($link) ?>" style="background:<?php echo esc_attr($category_color) ?>"><?php  echo esc_html($category->name)?></a>
    <?php
    }
?>

