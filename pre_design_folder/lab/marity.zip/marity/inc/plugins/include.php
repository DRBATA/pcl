<?php

require_once MARITY_INC_ROOT_DIR . '/plugins/class-tgm-plugin-activation.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
include_once MARITY_INC_ROOT_DIR . '/plugins/plugins-activation.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
