<?php

include_once MARITY_INC_ROOT_DIR . '/footer/helper.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
