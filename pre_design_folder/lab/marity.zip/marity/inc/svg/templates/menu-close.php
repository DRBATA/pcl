<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox='0 0 60 60'>
    <rect width="60" height="60" rx="9" ry="9"/>
    <path d='M18 29h24v1H18z' fill="#fff"/>
    <path d='M29 18h1.2v23H29z' fill="#fff"/>
</svg>
