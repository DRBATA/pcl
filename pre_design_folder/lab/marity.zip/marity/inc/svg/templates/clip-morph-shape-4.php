<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg" width="436.5" height="436.5" viewBox="0 0 436.5 436.5">
    <?php
    $uniqueId = 'marity-' . wp_unique_id(). '-'. mt_rand(0, 1000) ;

    $d1 = 'M435 224.5c0 120-108.9 215.4-227.7 210.3-118.5-5-199-97.6-206.7-217.4C-8.4 77 90.7-2.8 209.3.1 333 3 435 104.5 435 224.5Z';
    $d2 = 'M427.5 209.9c0 119.5-65.4 227-188.3 217C122 417.4 15.8 355 8.2 235.8-.8 95.9 79.2.9 196.5 7.8c118 7 231 82.6 231 202Z';
    $d3 = 'M434.3 210.4c0 120.9-102 252-216.8 221.6C103.9 402 12.3 338.1 4.7 217.5-4.2 75.9 124.2-.1 241.5 6.9c117.8 7 192.8 82.5 192.8 203.5Z';

    ?>
    <clipPath id="<?php echo esc_attr( $uniqueId ) ?>" clipPathUnits="objectBoundingBox">
        <path d= "<?php echo esc_attr( $d1 ); ?>"/>
        <path d= "<?php echo esc_attr( $d2); ?>"/>
        <path d= "<?php echo esc_attr( $d3); ?>"/>
    </clipPath>
</svg>
