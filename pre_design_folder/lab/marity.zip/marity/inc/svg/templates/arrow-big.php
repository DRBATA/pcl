<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg" width="32.551" height="32.5" viewBox="0 0 32.551 32.5">
    <g>
        <path d="M0 .5h32.051v32"/>
        <path stroke-width=".75" d="M32.0493.5 2.1383 30.411"/>
    </g>
    <g>
        <path d="M0 .5h32.051v32"/>
        <path stroke-width=".75" d="M32.0493.5 2.1383 30.411"/>
    </g>
</svg>
