<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15"><path fill="currentColor" d="M14 7.5 0 15V0l14 7.5z"/></svg>
