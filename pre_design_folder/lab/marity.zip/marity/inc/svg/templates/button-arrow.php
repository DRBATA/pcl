<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg" width="11.9" height="11.9" viewBox="0 0 11.9 11.9">
    <g>
        <path d="M0 .5h11.372v11.354"/>
        <path stroke-width=".75" d="M11.3715.5.7587 11.1128"/>
    </g>
    <g>
        <path d="M0 .5h11.372v11.354"/>
        <path stroke-width=".75" d="M11.3715.5.7587 11.1128"/>
    </g>
</svg>
