<svg class="<?php echo esc_attr( $class ); ?>" xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox='0 0 60 60'>
    <rect width="60" height="60" rx="9" ry="9"></rect>
    <path d='M18 24.2h24v1H18z' fill="#fff"></path>
    <path d='M18 34.1h24v1H18z' fill="#fff"></path>
</svg>
