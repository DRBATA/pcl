<?php

include_once MARITY_INC_ROOT_DIR . '/woocommerce/class-marity-woocommerce.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
