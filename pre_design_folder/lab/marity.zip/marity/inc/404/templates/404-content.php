<div id="qodef-404-page">
	<h1 class="qodef-404-title"><?php echo esc_html( $title ); ?></h1>

	<p class="qodef-404-text"><?php echo esc_html( $text ); ?></p>

	<div class="qodef-404-button">
		<?php
        if ( marity_is_installed( 'core' ) ) {
            $button_params = array(
                'button_link' => esc_url(home_url('/')),
                'button_text' => esc_html($button_text),
            );

            marity_render_button_element($button_params);
        }
        else {
            $button_params = array(
                'link' => esc_url(home_url('/')),
                'text' => esc_html('Back to home'),
            );
            marity_render_button_element($button_params);
        }
		?>
	</div>
</div>
