<?php

include_once MARITY_INC_ROOT_DIR . '/rest/class-marity-rest-api.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
