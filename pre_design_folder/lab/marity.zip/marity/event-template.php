<?php
/*
Template Name: Timetable Event
*/
get_header();

// Include event content template
if ( marity_is_installed( 'core' ) ) {
	marity_core_template_part( 'plugins/timetable', 'templates/content' );
}

get_footer();
