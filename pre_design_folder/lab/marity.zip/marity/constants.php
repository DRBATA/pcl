<?php

define( 'MARITY_ROOT', get_template_directory_uri() );
define( 'MARITY_ROOT_DIR', get_template_directory() );
define( 'MARITY_ASSETS_ROOT', MARITY_ROOT . '/assets' );
define( 'MARITY_ASSETS_ROOT_DIR', MARITY_ROOT_DIR . '/assets' );
define( 'MARITY_ASSETS_CSS_ROOT', MARITY_ASSETS_ROOT . '/css' );
define( 'MARITY_ASSETS_CSS_ROOT_DIR', MARITY_ASSETS_ROOT_DIR . '/css' );
define( 'MARITY_ASSETS_JS_ROOT', MARITY_ASSETS_ROOT . '/js' );
define( 'MARITY_ASSETS_JS_ROOT_DIR', MARITY_ASSETS_ROOT_DIR . '/js' );
define( 'MARITY_INC_ROOT', MARITY_ROOT . '/inc' );
define( 'MARITY_INC_ROOT_DIR', MARITY_ROOT_DIR . '/inc' );
