<?php

get_header();

// Include content template
marity_template_part( 'content', 'templates/content', 'search' );

get_footer();
